import React, { useState } from "react";
import axios from "axios";
import { Container, Row, Col, Form, Button, Card } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import logo from "./honeywell-logo.png";

function App() {
  const [inputText, setInputText] = useState("");
  const [name, setName] = useState("Prakash");
  const [encryptedText, setEncryptedText] = useState("");

  const handleEncrypt = async () => {
    try {
      const response = await axios.post(
        "http://localhost:8081/api/encrypt2", // Matches server.port=8081
        inputText,
        {
          params: { salt: name },
          headers: { "Content-Type": "text/plain" },
        }
      );
      setEncryptedText(response.data);
    } catch (error) {
      console.error(
        "Encryption error:",
        error.response ? error.response.data : error.message
      );
      if (error.response) {
        setEncryptedText(
          `Error: ${error.response.status} - ${error.response.data}`
        );
      } else if (error.request) {
        setEncryptedText(
          `Network Error: Backend not reachable at http://localhost:8081. Check server status.`
        );
      } else {
        setEncryptedText(`Error: ${error.message}`);
      }
    }
  };

  return (
    <div className="app-background">
      <Container fluid className="h-100">
        <Row className="justify-content-center align-items-center min-vh-100">
          <Col md={6} lg={4}>
            <Card className="shadow-lg encryption-card">
              <Card.Body>
                <div className="text-center mb-4">
                  <img src={logo} alt="Honeywell Logo" className="logo" />
                  <h1 className="app-title">Honeywell Encryption</h1>
                </div>
                <Form>
                  <Form.Group className="mb-3">
                    <Form.Label className="form-label">
                      Your Name (Salt)
                    </Form.Label>
                    <Form.Control
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Enter your name"
                      className="form-input"
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label className="form-label">
                      Text to Encrypt
                    </Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder="Enter text to encrypt"
                      className="form-input"
                    />
                  </Form.Group>
                  <Button
                    variant="primary"
                    onClick={handleEncrypt}
                    className="w-100 encrypt-button"
                  >
                    Encrypt
                  </Button>
                </Form>
                {encryptedText && (
                  <div className="mt-4 result-box">
                    <h3 className="result-title">Encrypted Text:</h3>
                    <p className="result-text">{encryptedText}</p>
                  </div>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default App;
